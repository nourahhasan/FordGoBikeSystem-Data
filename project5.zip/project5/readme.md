### ( Ford GoBike System Data )
#### by ( Nourah Hasan )


## Dataset

> 
Ford GoBike is the Bay Area's bike share system, with thousands of bikes at hundreds of station in San Francisco, San Jose and the East Bay.



## Summary of Findings

> 
Most of the members' ages ranged from 20 to 60 years old
Most of the members were from Males
Most of the members were from subscriber type 
Most of the trips start and end times are between 7 am and 7 pm
Members of subscriber type spend longer times on trips
Members of customer type travel longer distances on trips
Members of subscriber are more use and share bikes in their trips
The Males rides longer distances on trips
All types of flights The flight start and end hours are approximately the same


## Key Insights for Presentation

> 
The insights will reveal to us about two types of members : (the subscriber and the customer)  and each of them has its own specifications.

shows us the popular working times of the members and the maximum peak times. 

It shows us the types of gender of members and  each types of gender has a characteristics such as the duration of rides bike and the distances trips .


It reveals to us about the average ages of members and how age affects the quality of performance for the members in terms of the duration he takes in the trips and the distance he trip from the start point of station to the end point of station .